// src/config.js

module.exports = {
    // Use your actual MongoDB URI
    mongoURI : "mongodb+srv://highlandhistoriesdeveloper:RvWKjUnNKacdWaX1@cluster0.pz0l5dq.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
};